-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2021 at 03:39 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `exotech`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `Cart_ID` int(11) NOT NULL,
  `Product_ID` int(11) NOT NULL,
  `Transaction_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_ID` int(11) NOT NULL,
  `First_name` text NOT NULL,
  `Last_name` text NOT NULL,
  `Contact_Number` int(11) NOT NULL,
  `Email` int(11) NOT NULL,
  `Address` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `Product_ID` int(11) NOT NULL,
  `Name` text NOT NULL,
  `Category` text NOT NULL,
  `Quantity` int(11) NOT NULL DEFAULT 999,
  `Price` decimal(11,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`Product_ID`, `Name`, `Category`, `Quantity`, `Price`) VALUES
(1, 'AMD Ryzen 5 5600X (AM4)', 'Processor', 999, '347.99'),
(2, 'AMD Ryzen 9 5950X (AM4)', 'Processor', 999, '799.99'),
(3, 'Intel Core i5 12600k LGA 1700', 'Processor', 999, '199.99'),
(4, 'Intel Core i5 11400f LGA 1200', 'Processor', 999, '156.99'),
(5, '16gb GSkill DDR5 4400', 'RAM', 999, '164.99'),
(6, '16gb TeamGroup DDR4 3200', 'RAM', 999, '59.99'),
(7, 'Asus Prime B550M-K (AM4)', 'Motherboard', 999, '109.99'),
(8, 'Gigabyte X570S Aorus Master (AM4)', 'Motherboard', 999, '389.99'),
(9, 'Gigabyte Z590 Aorus Tachyon (LGA1200)', 'Motherboard', 999, '529.99'),
(10, 'Asus ROG Maximus Z690 Extreme (LGA1700)', 'Motherboard', 999, '599.99'),
(11, 'MSI Pro Z690-A (LGA1700)', 'Motherboard', 999, '239.99'),
(12, 'ASRock B560M Pro4 (LGA1200)', 'Motherboard', 999, '134.99'),
(13, '120gb Patriot Burst SSD sata', 'SSD', 999, '21.99'),
(14, '1tb Samsung 870 EVO SSD sata', 'SSD', 999, '134.99'),
(15, '128gb Patriot P300 SSD NVMe Gen3', 'SSD', 999, '24.99'),
(16, '1tb WD black SN850 SSD NVMe Gen4', 'SSD', 999, '164.99'),
(17, '500gb Seagate Barracuda', 'HDD', 999, '21.99'),
(18, '1tb WD Black hdd', 'HDD', 999, '67.99'),
(19, 'Cooler Master CM 600watts', 'PSU', 999, '44.99'),
(20, 'FSP 700watts Hydro K', 'PSU', 999, '59.99'),
(21, 'Seasonic Prime PX Platinum 850watts', 'PSU', 999, '158.99'),
(22, 'Noctua NH U12S Single Fan cpu AIR cooler', 'Cooling', 999, '61.99'),
(23, 'IDCooling Auraflow AF X360', 'Cooling', 999, '74.99'),
(24, 'NZXT H210 TG, ITX Matte black, 2x120mm', 'Case', 999, '89.99'),
(25, 'Lian li O11 Dynamic Mini, white', 'Case', 999, '149.99'),
(26, '27\" Gigabyte G27Q LED IPS 144hz Adaptive Freesync 2K 2560 x 1440p', 'Monitor', 999, '335.99'),
(27, '24\" Gigabyte G24F RGB LED IPS 170hz Adaptive Freesync 1080p', 'Monitor', 999, '255.99'),
(29, ' Razer Black Widow v3', 'Keyboard', 999, '99.99'),
(30, ' Logitech GPro X TKL', 'Keyboard', 999, '64.99'),
(32, 'Razer Viper Mini RGB', 'Mouse', 999, '39.99'),
(33, 'Logitech G304 black', 'Mouse', 999, '89.99'),
(34, 'HyperX Cloud II Wireless 7.1', 'Headset', 999, '99.99'),
(35, 'Logitech G733 black', 'Headset', 999, '109.99'),
(36, 'Fairphone4 6gb/128gb', 'Smartphone', 999, '699.99'),
(37, 'Iphone 13 Midnight 128gb', 'Smartphone', 999, '999.99'),
(38, 'Light L16', 'Camera', 999, '1999.99'),
(39, 'Sony a7 III Mirrorless Camera', 'Camera', 999, '1998.99');

-- --------------------------------------------------------

--
-- Table structure for table `sale`
--

CREATE TABLE `sale` (
  `Transaction_ID` int(11) NOT NULL,
  `Customer_ID` int(11) NOT NULL,
  `Transaction_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`Cart_ID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_ID`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`Product_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `Cart_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Customer_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `Product_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
